﻿namespace MicrosoftCrop_MSFT_.Models
{
    public class Stock
    {
       

   public string? StockSymbol { get; set; }
   public string? StockName { get; set; }
   public double Price { get; set; }
   public uint? Quantity { get; set; }
       
    }
}
