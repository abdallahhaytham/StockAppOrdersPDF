﻿using MicrosoftCrop_MSFT_.Models;
using StockAppwithxUnit.Entities;

namespace StocksApp.ServiceContract.DTO
{
    public class BuyOrderResponse
    {
        public Guid BuyOrderID { get; set; }

        public string? StockSymbol { get; set; }

        public string? StockName { get; set; }

        public DateTime? DateAndTimeOfOrder { get; set; }

        public uint? Quantity { get; set; }

        public double? Price { get; set; }

        public double? TradeAmount {  get; set; }
        public override bool Equals(object? obj)
        {
            if (obj == null) return false;

            if (obj.GetType() != typeof(BuyOrderResponse)) return false;

         
            BuyOrderResponse other = (BuyOrderResponse)obj;
            return BuyOrderID == other.BuyOrderID &&
                   StockSymbol == other.StockSymbol &&
                   StockName == other.StockName &&
                   DateAndTimeOfOrder == other.DateAndTimeOfOrder &&
                   Quantity == other.Quantity &&
                   Price == other.Price &&
                   TradeAmount == other.TradeAmount;


        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    public static class BuyOrderResponseExtensions
    {
        public static BuyOrderResponse ToBuyOrderResponse(this  
            BuyOrder stock)
        {
            return new BuyOrderResponse()
            {
             
                StockSymbol = stock.StockSymbol,
                StockName = stock.StockName,
                DateAndTimeOfOrder = stock.DateAndTimeOfOrder,
                Quantity = stock.Quantity,
                Price = stock.Price,
                TradeAmount = stock.Price * stock.Quantity
            };
        }
    }
}
