﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MicrosoftCrop_MSFT_.Models;
using MicrosoftCrop_MSFT_.ServiceContract;
using MicrosoftCrop_MSFT_.Services;
using StockAppwithxUnit.Models;
using StockAppwithxUnit.ServiceContract;
using StockAppwithxUnit.Services;
using StocksApp;
using StocksApp.ServiceContract.DTO;
using System.Threading.Tasks;

namespace MicrosoftCrop_MSFT_.Controllers
{
    [Route("[controller]")]
    public class TradeController : Controller
    {
        private readonly IFinnhubService _microsoftCorp;
        private readonly IOptions<TradingOptions> _tradingOptions;
        private readonly IStocksService _stocksService;
        private readonly IConfiguration _configuration;

        public TradeController(
            IFinnhubService microsoftCorp,
            IOptions<TradingOptions> tradingOptopn,
            IStocksService stocksService,
            IConfiguration configuration
        )
        {
            _microsoftCorp = microsoftCorp;
            _tradingOptions = tradingOptopn;
            _stocksService = stocksService;
            _configuration = configuration;
        }

        [Route("/")]
        [Route("[action]")]

        public async Task<IActionResult> Index()
        {
       
            if(_tradingOptions.Value.DefaultStockSymbol==null)
            {
                _tradingOptions.Value.DefaultStockSymbol="MSFT";
            }
            Dictionary<string, object>? companyprofile = await _microsoftCorp.GetCompanyProfile(_tradingOptions.Value.DefaultStockSymbol!);

            Dictionary<string, object>? stockPriceQuote = await _microsoftCorp.GetStockPriceQuote(_tradingOptions.Value.DefaultStockSymbol!);


           
                Stock stock = new Stock()
                {
                    StockSymbol = _tradingOptions.Value.DefaultStockSymbol,
                    StockName = companyprofile!["name"].ToString(),


                    Price = Convert.ToDouble(stockPriceQuote!["c"].ToString()),
                    Quantity = Convert.ToUInt32(
                    Convert.ToDouble(stockPriceQuote["t"].ToString()) /
                    Convert.ToDouble(stockPriceQuote["c"].ToString()))



                };
            ViewBag.FinnhubToken = _configuration["FinnhubToken"];
            return View(stock);

            
        }
        [Route("[action]")]
        [HttpPost]

        public async Task<IActionResult> SellOrder(SellOrderRequest sellOrderRequest)
        {
            sellOrderRequest.DateAndTimeOfOrder = DateTime.Now;

            ModelState.Clear();
            TryValidateModel(sellOrderRequest);
           if(!ModelState.IsValid)
            {
                ViewBag.Errors=ModelState.Values.SelectMany(x => x.Errors).Select(x=>x.ErrorMessage).ToList();
                Stock stock = new Stock() { StockName = sellOrderRequest.StockName, Quantity = sellOrderRequest.Quantity, StockSymbol = sellOrderRequest.StockSymbol };
                return View("Index",stock);
            }


            SellOrderResponse sellOrderResponse = await _stocksService.CreateSellOrder(sellOrderRequest);

            return RedirectToAction(nameof(Orders));

        }
        [Route("[action]")]
        [HttpPost]

        public async Task<IActionResult> BuyOrder(BuyOrderRequest buyOrderRequest)
        {

            buyOrderRequest.DateAndTimeOfOrder=DateTime.Now;

            ModelState.Clear();
            if(!ModelState.IsValid)
            {
                ViewBag.Errors=ModelState.Values.SelectMany(x => x.Errors).Select(x=>x.ErrorMessage);
                Stock stock = new Stock() {StockName =buyOrderRequest.StockName,Quantity=buyOrderRequest.Quantity ,StockSymbol= buyOrderRequest.StockSymbol };
                return View("Index",stock);
            }


            BuyOrderResponse buyOrderResponse=await _stocksService.CreateBuyOrder(buyOrderRequest);

            return RedirectToAction(nameof(Orders));

        }
        [Route("[action]")]

        public async Task<IActionResult>Orders()
        {
         List<BuyOrderResponse> buyOrders  = await   _stocksService.GetBuyOrders();
            List<SellOrderResponse> sellOrders = await _stocksService.GetSellOrders();

            Orders orders = new Orders()
            {
                BuyOrders= buyOrders,SellOrders= sellOrders
            };


            return View(orders);

        }
        [Route("[action]")]
        [HttpGet]
        public async Task<IActionResult> OrdersPDF()
        {
           List<BuyOrderResponse> buyOrders = await _stocksService.GetBuyOrders();
            List<SellOrderResponse> sellOrders = await _stocksService.GetSellOrders();

            Orders orders = new Orders()
            {
                BuyOrders = buyOrders,
                SellOrders = sellOrders
            };

            return new Rotativa.AspNetCore.ViewAsPdf("OrdersPDF",orders,ViewData) {
            
            PageMargins=new Rotativa.AspNetCore.Options.Margins(20,20,20,20)

            ,PageOrientation=Rotativa.AspNetCore.Options.Orientation.Landscape

            };

        }
       



    }
}
