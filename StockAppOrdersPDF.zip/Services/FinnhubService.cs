﻿using MicrosoftCrop_MSFT_.ServiceContract;
using Services.Helpers;
using StocksApp.ServiceContract.DTO;

namespace MicrosoftCrop_MSFT_.Services
{
    public class FinnhubService : IFinnhubService
    {
private readonly IHttpClientFactory _httpClientFactory;    
        
        private readonly IConfiguration _configuration;

        Dictionary<string, object> _dictionaryCompanyProfile = new Dictionary<string, object>();
        Dictionary<string, object> _dictionaryStockPriceQuote = new Dictionary<string, object>();

        public   FinnhubService(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }
        public FinnhubService()
        {
            _httpClientFactory = null!;
            _configuration = null!;
        }
        public async Task<Dictionary<string, object>?> GetCompanyProfile(string stockSymbol)
        {
            using (HttpClient client = _httpClientFactory.CreateClient())
            {
                HttpRequestMessage httpRequestMessage = new HttpRequestMessage() { 
                   RequestUri= new Uri($"https://finnhub.io/api/v1/stock/profile2?symbol={stockSymbol}&token={_configuration["FinnhubToken"]}") 
                                   , Method = HttpMethod.Get

                    };
                HttpResponseMessage response = await client.SendAsync(httpRequestMessage);

                Stream stream=response.Content.ReadAsStream();

                StreamReader streamReader=new StreamReader(stream);


                Dictionary<string, object>? dictionary= System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(streamReader.ReadToEnd());

                if(dictionary==null)
                {
                    throw new Exception("No data found");
                }
                _dictionaryCompanyProfile = dictionary;

                return dictionary;

            }
        }

        public async Task<Dictionary<string, object>?> GetStockPriceQuote(string stockSymbol)
        {

            using (HttpClient client = _httpClientFactory.CreateClient())
            {
                HttpRequestMessage httpRequestMessage = new HttpRequestMessage()
                {
                    RequestUri = new Uri($"https://finnhub.io/api/v1/quote?symbol={stockSymbol}&token={_configuration["FinnhubToken"]}")
                                   ,
                    Method = HttpMethod.Get

                };
                HttpResponseMessage response = await client.SendAsync(httpRequestMessage);

                Stream stream = response.Content.ReadAsStream();

                StreamReader streamReader = new StreamReader(stream);


                Dictionary<string, object>? dictionary = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(streamReader.ReadToEnd());

                if (dictionary == null)
                {
                    throw new Exception("No data found");
                }

                _dictionaryStockPriceQuote = dictionary;

                return dictionary;

            }
        }

      
    }
}
