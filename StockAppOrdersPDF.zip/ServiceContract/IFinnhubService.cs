﻿using StocksApp.ServiceContract.DTO;

namespace MicrosoftCrop_MSFT_.ServiceContract
{
    public interface IFinnhubService
    {
        Task<Dictionary<string, object>?> GetCompanyProfile(string stockSymbol);
        Task<Dictionary<string, object>?> GetStockPriceQuote(string stockSymbol);




    }
}
