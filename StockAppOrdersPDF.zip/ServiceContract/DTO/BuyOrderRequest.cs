﻿using MicrosoftCrop_MSFT_.Models;
using StockAppwithxUnit.Entities;
using System.ComponentModel.DataAnnotations;

namespace StocksApp.ServiceContract.DTO
{
    public class BuyOrderRequest
    {
        [Required(ErrorMessage = "Stock symbol is required")]
        public string? StockSymbol { get; set; }

        [Required(ErrorMessage = "Stock name is required")]
        public string? StockName { get; set; }

        [CustomValidationOrder("2000-01-01")]
        public DateTime DateAndTimeOfOrder { get; set; }

        [Range(1, 100000, ErrorMessage = "{0} should be between 1 and 100000]")]
      public  uint? Quantity { get; set; }

        [Range(1, 10000, ErrorMessage = "{0} should be between 1 and 10000]")]

        public double? Price { get; set; }



        public  BuyOrder BuyOrder()
        {
            return new BuyOrder()
            {

                StockSymbol = StockSymbol,
                StockName = StockName,
                DateAndTimeOfOrder = DateAndTimeOfOrder,
                Quantity = Quantity,
                Price = Price
            };
        }





    }
}
