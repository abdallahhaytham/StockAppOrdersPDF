﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

public class CustomValidationOrder : ValidationAttribute
{
    string _MinimumDate = "2000-01-01";


    public CustomValidationOrder(string MinimumDate)
    {
        _MinimumDate = MinimumDate;
    }
    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if(value==null)
        {
            return new ValidationResult("OrderDate can't be blank");

        }
        DateTime orderDate = (DateTime)value;
        DateTime minimumDate = DateTime.Parse(_MinimumDate);

        if (orderDate >= minimumDate)
        {
          return ValidationResult.Success;
        }
        else
        {
            return new ValidationResult($"Order date must be on or after {_MinimumDate}");
        }

    }


}
