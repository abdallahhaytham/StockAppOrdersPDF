using Microsoft.EntityFrameworkCore;
using MicrosoftCrop_MSFT_.ServiceContract;
using MicrosoftCrop_MSFT_.Services;
using StockAppwithxUnit.Entities;
using StockAppwithxUnit.ServiceContract;
using StockAppwithxUnit.Services;
using StocksApp;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient();
builder.Services.AddScoped<IFinnhubService, FinnhubService>();
builder.Services.AddScoped<IStocksService, StocksService>();
builder.Services.Configure<TradingOptions>(builder.Configuration.GetSection("TradingOptions"));



builder.Services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("StockAppDatabase")));
var app = builder.Build();

Rotativa.AspNetCore.RotativaConfiguration.Setup("wwwroot",wkhtmltopdfRelativePath:"Rotativa");

app.UseStaticFiles();
app.UseRouting();
app.MapControllers();


app.Run();
