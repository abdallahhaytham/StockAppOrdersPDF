﻿using Microsoft.EntityFrameworkCore;

namespace StockAppwithxUnit.Entities
{
    public class OrdersDbContext: DbContext
    {
        public OrdersDbContext(DbContextOptions<OrdersDbContext> options) : base(options)
        {
        }
        public DbSet<SellOrder> sellOrders { get; set; }
        public DbSet<BuyOrder> buyOrders { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<SellOrder>().ToTable("SellOrders");
            modelBuilder.Entity<BuyOrder>().ToTable("BuyOrders");
        }
    }
}
