﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Services.Helpers;
using StockAppwithxUnit.Entities;
using StockAppwithxUnit.ServiceContract;
using StocksApp.ServiceContract.DTO;

namespace StockAppwithxUnit.Services
{
    public class StocksService : IStocksService
    {
        private readonly OrdersDbContext _context;

        public StocksService(OrdersDbContext context)
        {
            _context = context;
        }
        public async Task<BuyOrderResponse> CreateBuyOrder(BuyOrderRequest buyOrderRequest)
        {
            if (buyOrderRequest == null)
            {
                throw new ArgumentNullException(nameof(buyOrderRequest));
            }
            ValidationHelper.ModelValidation(buyOrderRequest);

            BuyOrder buyOrder= buyOrderRequest.BuyOrder();

            buyOrder.BuyOrderId=Guid.NewGuid();

            await _context.AddAsync(buyOrder);
            await _context.SaveChangesAsync();

           
            return  buyOrder.ToBuyOrderResponse();
            
        }

        public async Task<SellOrderResponse> CreateSellOrder(SellOrderRequest? sellOrderRequest)
        {
            if (sellOrderRequest == null)
            {
                throw new ArgumentNullException(nameof(sellOrderRequest));
            }
            ValidationHelper.ModelValidation(sellOrderRequest);

            SellOrder sellOrder = sellOrderRequest.ToSellOrder();

            sellOrder.SellOrderID = Guid.NewGuid();

            
            await _context.AddAsync(sellOrder);
            await _context.SaveChangesAsync();

         
            return sellOrder.ToSellOrderResponse();

        }

        public async Task<List<BuyOrderResponse>> GetBuyOrders()

        {
            var buyOrders =await _context.buyOrders.ToListAsync();
            return buyOrders.Select( b => b.ToBuyOrderResponse()).ToList();
        }

        public async Task<List<SellOrderResponse>> GetSellOrders()
        {

            var sellOrders = await _context.sellOrders.ToListAsync();
            return sellOrders.Select(temp => temp.ToSellOrderResponse()).ToList();


        }
    }
}
